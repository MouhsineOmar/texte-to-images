export const APP_NAME = "AI Image Generator";
